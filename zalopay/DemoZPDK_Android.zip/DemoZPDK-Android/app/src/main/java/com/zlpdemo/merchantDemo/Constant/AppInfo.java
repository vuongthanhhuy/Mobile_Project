package com.zlpdemo.merchantDemo.Constant;

public class AppInfo {
    public static final int APP_ID = 553;
    public static final String MAC_KEY = "9phuAOYhan4urywHTh0ndEXiV3pKHr5Q";
    public static final String URL_CREATE_ORDER = "https://sandbox.zalopay.com.vn/v001/tpe/createorder";
}
